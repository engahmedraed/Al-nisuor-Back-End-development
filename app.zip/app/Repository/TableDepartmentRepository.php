<?php
namespace App\Repository;

use id;
use JWTAuth;
use App\Models\TableDepartment;
use App\Repository\BRepository;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Validator;
use Tymon\JWTAuth\Exceptions\JWTException;

class TableDepartmentRepository extends BRepository {
    //
}