<?php
namespace App\Repository;

use id;
use JWTAuth;
use App\Models\Social;
use App\Repository\BRepository;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Validator;
use Tymon\JWTAuth\Exceptions\JWTException;

class SocialRepository extends BRepository {
    //
}